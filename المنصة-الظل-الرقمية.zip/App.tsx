
import React, { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { VideoPlayer } from './components/VideoPlayer';
import { Schedule } from './components/Schedule';
import { AiAssistant } from './components/AiAssistant';
import { Match, Sport } from './types';
import { SPORTS, MATCHES } from './constants';

const App: React.FC = () => {
  const [selectedSport, setSelectedSport] = useState<Sport>(SPORTS[0]);
  const [isSidebarOpen, setSidebarOpen] = useState<boolean>(false);

  const liveMatch = MATCHES.find(m => m.sportId === selectedSport.id && m.live) || MATCHES.find(m => m.sportId === selectedSport.id);

  const handleSelectSport = (sport: Sport) => {
    setSelectedSport(sport);
    if(window.innerWidth < 768) {
        setSidebarOpen(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white overflow-hidden">
      <Header onMenuClick={() => setSidebarOpen(!isSidebarOpen)} />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar 
          sports={SPORTS} 
          selectedSport={selectedSport} 
          onSelectSport={handleSelectSport}
          isOpen={isSidebarOpen}
          setIsOpen={setSidebarOpen}
        />
        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-y-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <VideoPlayer match={liveMatch} />
              <Schedule matches={MATCHES.filter(m => m.sportId === selectedSport.id)} />
            </div>
            <div className="lg:col-span-1">
              <AiAssistant match={liveMatch} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
