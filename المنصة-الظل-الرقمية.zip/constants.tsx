
import React from 'react';
import { Sport, Match } from './types';

export const FootballIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12,2A10,10,0,1,0,22,12,10,10,0,0,0,12,2Zm0,18a8,8,0,1,1,8-8A8,8,0,0,1,12,20ZM12,6.34l1.3,2.78L16,9.3l-1.93,2.15.65,2.95-2.72-1.5-2.72,1.5.65-2.95L8,9.3l2.7.18ZM11,15h2v2H11Z" /></svg>
);

export const BasketballIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12,2A10,10,0,1,0,22,12,10,10,0,0,0,12,2Zm0,18a8,8,0,1,1,8-8A8,8,0,0,1,12,20Zm4.62-5.71L15.5,13.17,17.2,15,16,16.2l-1.7-1.83-1.12,1.12L15,17.2,13.8,16,12.09,17.71a3,3,0,0,1-4.24,0l-1-1a3,3,0,0,1,0-4.24l3.54-3.54,1.41,1.41L8.25,13.88l1,1a1,1,0,0,0,1.41,0L13.41,12l-1.12-1.12L10.59,9.17l1.41-1.41,3.54,3.54a3,3,0,0,1,1.08,2.12Z" /></svg>
);

export const TennisIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12.01,2C6.49,2,2,6.49,2,12s4.49,10,10.01,10S22,17.51,22,12S17.53,2,12.01,2z M12,20c-4.41,0-8-3.59-8-8s3.59-8,8-8s8,3.59,8,8S16.41,20,12,20z M14.6,15.11l-2.07-2.07c.34-.63.57-1.33.57-2.04,0-2.21-1.79-4-4-4s-4,1.79-4,4,1.79,4,4,4c.71,0,1.41-.23,2.04-.57l2.07,2.07,1.36-1.36z M9.1,13.1c-1.1,0-2-0.9-2-2s0.9-2,2-2,2,0.9,2,2S10.2,13.1,9.1,13.1z" /></svg>
);

export const SPORTS: Sport[] = [
  { id: 'football', name: 'كرة القدم', icon: <FootballIcon className="w-6 h-6" /> },
  { id: 'basketball', name: 'كرة السلة', icon: <BasketballIcon className="w-6 h-6" /> },
  { id: 'tennis', name: 'التنس', icon: <TennisIcon className="w-6 h-6" /> },
];

export const MATCHES: Match[] = [
    { id: 1, sportId: 'football', teamA: 'الأهلي', teamB: 'الزمالك', time: 'مباشر الآن', live: true, score: '2 - 1' },
    { id: 2, sportId: 'football', teamA: 'الهلال', teamB: 'النصر', time: '21:00', live: false },
    { id: 3, sportId: 'football', teamA: 'الوداد', teamB: 'الرجاء', time: '23:00', live: false },
    { id: 4, sportId: 'basketball', teamA: 'الاتحاد', teamB: 'الأهلي', time: 'مباشر الآن', live: true, score: '88 - 85' },
    { id: 5, sportId: 'basketball', teamA: 'الكويت', teamB: 'القادسية', time: '20:30', live: false },
    { id: 6, sportId: 'tennis', teamA: 'أنس جابر', teamB: 'ماريا سكاري', time: 'مباشر الآن', live: true, score: '6-4, 3-2' },
    { id: 7, sportId: 'tennis', teamA: 'نوفاك دجوكوفيتش', teamB: 'رافاييل نادال', time: '19:00', live: false },
];
