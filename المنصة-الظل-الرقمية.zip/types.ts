// Fix: Import React types to make JSX types available.
import type React from 'react';

export interface Sport {
  id: string;
  name: string;
  icon: React.ReactElement;
}

export interface Match {
  id: number;
  sportId: string;
  teamA: string;
  teamB: string;
  time: string;
  live: boolean;
  score?: string;
}

export interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
}
