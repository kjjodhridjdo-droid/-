
import React from 'react';
import { Match } from '../types';

interface VideoPlayerProps {
    match: Match | undefined;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ match }) => {
    if (!match) {
        return (
            <div className="aspect-video w-full bg-gray-800 rounded-xl flex items-center justify-center mb-4">
                <p className="text-gray-400">الرجاء اختيار رياضة لعرض المباراة</p>
            </div>
        )
    }

    return (
        <div className="mb-4">
            <div className="relative aspect-video w-full bg-black rounded-xl overflow-hidden shadow-2xl shadow-blue-500/20">
                <img 
                    src={`https://picsum.photos/seed/${match.id}/1280/720`} 
                    alt="بث رياضي" 
                    className="w-full h-full object-cover opacity-70"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20"></div>
                
                {match.live && (
                    <div className="absolute top-4 right-4 flex items-center gap-2 bg-red-600/80 text-white px-3 py-1 rounded-full text-sm font-bold animate-pulse">
                        <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                        </span>
                        مباشر
                    </div>
                )}

                <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 bg-gradient-to-t from-black/80 to-transparent">
                    <h2 className="text-2xl md:text-3xl font-bold">{`${match.teamA} ضد ${match.teamB}`}</h2>
                    {match.live && match.score && (
                        <p className="text-xl md:text-2xl font-mono text-blue-300 mt-2">{match.score}</p>
                    )}
                </div>
            </div>
        </div>
    );
};
