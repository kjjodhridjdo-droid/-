
import React from 'react';
import { FootballIcon } from '../constants';

interface HeaderProps {
    onMenuClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  return (
    <header className="bg-gray-800/50 backdrop-blur-sm shadow-lg p-4 flex items-center justify-between z-20 shrink-0">
      <div className="flex items-center gap-3">
        <div className="text-blue-400">
            <FootballIcon className="w-8 h-8"/>
        </div>
        <h1 className="text-xl md:text-2xl font-bold tracking-wider">
          المنصة الظل الرقمية
        </h1>
      </div>
      <div className="flex items-center gap-4">
        {/* Placeholder for future icons like search or profile */}
        <button className="md:hidden p-2 rounded-full hover:bg-gray-700 transition-colors" onClick={onMenuClick}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
          </svg>
        </button>
      </div>
    </header>
  );
};
