
import React from 'react';
import { Match } from '../types';

interface ScheduleProps {
  matches: Match[];
}

export const Schedule: React.FC<ScheduleProps> = ({ matches }) => {
  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-4 shadow-lg">
      <h3 className="text-xl font-bold mb-4 border-b border-gray-700 pb-2">جدول المباريات</h3>
      <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
        {matches.map((match) => (
          <div key={match.id} className={`flex justify-between items-center p-3 rounded-lg transition-colors ${match.live ? 'bg-blue-500/20' : 'bg-gray-700/40'}`}>
            <div className="flex flex-col">
              <span className="font-semibold">{`${match.teamA} ضد ${match.teamB}`}</span>
              <span className="text-sm text-gray-400">{match.time}</span>
            </div>
            {match.live && match.score && (
              <div className="font-mono text-lg text-blue-300">{match.score}</div>
            )}
            {match.live && !match.score && (
              <div className="text-red-400 font-semibold animate-pulse text-sm">مباشر</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
