
import React from 'react';
import { Sport } from '../types';

interface SidebarProps {
  sports: Sport[];
  selectedSport: Sport;
  onSelectSport: (sport: Sport) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ sports, selectedSport, onSelectSport, isOpen, setIsOpen }) => {
    const sidebarClasses = `
        bg-gray-800/70 backdrop-blur-md transition-transform transform duration-300 ease-in-out z-10
        w-64 p-4 flex flex-col shrink-0
        md:relative md:translate-x-0
        absolute h-full
        ${isOpen ? 'translate-x-0' : 'translate-x-full'}
    `;

    return (
        <>
            {isOpen && <div className="fixed inset-0 bg-black/50 z-0 md:hidden" onClick={() => setIsOpen(false)}></div>}
            <aside className={sidebarClasses}>
                <h2 className="text-lg font-semibold mb-4 text-gray-300 border-b border-gray-700 pb-2">
                    القنوات الرياضية
                </h2>
                <nav className="flex flex-col gap-2">
                    {sports.map((sport) => (
                    <a
                        key={sport.id}
                        href="#"
                        onClick={(e) => {
                        e.preventDefault();
                        onSelectSport(sport);
                        }}
                        className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-200 ${
                        selectedSport.id === sport.id
                            ? 'bg-blue-500/80 text-white shadow-md'
                            : 'text-gray-300 hover:bg-gray-700/50 hover:text-white'
                        }`}
                    >
                        {sport.icon}
                        <span className="font-semibold">{sport.name}</span>
                    </a>
                    ))}
                </nav>
            </aside>
        </>
    );
};
