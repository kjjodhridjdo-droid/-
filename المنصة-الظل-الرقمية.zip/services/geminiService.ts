import { GoogleGenAI } from "@google/genai";
import { Match } from "../types";

// Per guidelines, the API key is sourced from environment variables and assumed to be present.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const getAiResponse = async (prompt: string, match: Match | undefined): Promise<string> => {
  try {
    const matchContext = match
      ? `المباراة الحالية هي بين ${match.teamA} و ${match.teamB}. النتيجة الحالية هي ${match.score || 'غير معروفة'}.`
      : 'لا توجد مباراة محددة حاليًا.';
    
    const systemInstruction = `أنت معلق رياضي خبير ومتحمس. وظيفتك هي تقديم تحليلات ثاقبة، والإجابة على أسئلة المستخدمين، وتوليد تعليقات حماسية حول الأحداث الرياضية. كن موجزًا ومباشرًا في إجاباتك. ${matchContext}`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            systemInstruction: systemInstruction,
            temperature: 0.7,
        }
    });

    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "عذرًا، حدث خطأ أثناء محاولة التواصل مع المساعد الذكي. يرجى المحاولة مرة أخرى لاحقًا.";
  }
};
